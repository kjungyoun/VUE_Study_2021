<template>
  <div>
    <update-form type="update" />
  </div>
</template>

<script>
import UpdateForm from '@/components/Form.vue';
export default {
  name: 'update',
  components: {
    UpdateForm,
  },
};
</script>

<style></style>
